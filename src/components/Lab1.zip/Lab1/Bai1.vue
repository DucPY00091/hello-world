<template>
    <div class="container">
        <headder class="row bg-warning p-2">Header</headder>
        <nav class="row bg-primary p-2">Nav</nav>
        <section class="row">
            <aside class="col-sm-4 bg-success  p-5"> Side bar </aside>
            <article class="col-sm-8 bg-info p-5">Main content</article>
        </section>
        <footer class="row bg-danger p-3"></footer>
    </div>
</template>

<script>

export default {
    name:"Lab1Bai1",
}
</script>

<style></style>